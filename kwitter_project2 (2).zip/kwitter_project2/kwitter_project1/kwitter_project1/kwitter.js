function add_user(){
    user_name1 = document.getElementById("name").value;
    localStorage.setItem("user name",user_name1);
   
    password = document.getElementById("password").value;
    localStorage.setItem("password",password);
    document.getElementById("done").innerHTML= "Done" + "!";
    
     window.location= "kwitter_room.html";
    }
    